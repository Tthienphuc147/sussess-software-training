module.exports = require("./index.js").default
